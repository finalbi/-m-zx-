package com.finalbi.evenbettertestmod.util;

import com.finalbi.evenbettertestmod.EvenBetterTestMod;
import com.finalbi.evenbettertestmod.blocks.BlockItemModel;
import com.finalbi.evenbettertestmod.blocks.PineappleOre;
import com.finalbi.evenbettertestmod.items.ItemModel;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class RegistryHandler {
    //register
    public static final DeferredRegister<Item> ITEMS = new DeferredRegister<>(ForgeRegistries.ITEMS, EvenBetterTestMod.MOD_ID);
    public static final DeferredRegister<Block> BLOCKS = new DeferredRegister<>(ForgeRegistries.BLOCKS, EvenBetterTestMod.MOD_ID);

    //items
    public static final RegistryObject<Item> PINEAPPLE = ITEMS.register("pineapple", ItemModel::new);

    //blocks
    public static final RegistryObject<Block> PINEAPPLE_ORE = BLOCKS.register("pineapple_ore", PineappleOre::new);

    //block items
    public static final RegistryObject<Item> PINEAPPLE_ORE_ITEM = ITEMS.register("pineapple_ore", () -> new BlockItemModel(PINEAPPLE_ORE));

    //Consructor/int functions
    public static void init(){
        ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        BLOCKS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }
}
